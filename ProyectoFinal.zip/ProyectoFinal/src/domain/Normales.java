package domain;

public class Normales extends Pieces {
    public Normales() {
        super();
    }

}
